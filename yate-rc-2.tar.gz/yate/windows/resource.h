//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Client.rc
//
#define IDD_TCLIENT                     101
#define IDI_NULLTEAM                    102
#define IDD_CALLS                       103
#define IDC_MAINTABS                    1000
#define IDC_STATUS                      1001
#define IDC_CALLTO                      1002
#define IDC_CALLS                       1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
